package com.example.exe2

import androidx.annotation.DrawableRes

data class Fliptop(
    val name: String,
    val caption: String,
    @DrawableRes val image: Int
)