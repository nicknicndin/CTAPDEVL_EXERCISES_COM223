package com.example.exe2

import android.annotation.SuppressLint
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

// TODO: Rename parameter arguments, choose names that match
// the fragment initialization parameters, e.g. ARG_ITEM_NUMBER
private const val ARG_PARAM1 = "param1"
private const val ARG_PARAM2 = "param2"

/**
 * A simple [Fragment] subclass.
 * Use the [homefragment.newInstance] factory method to
 * create an instance of this fragment.
 */
class homefragment : Fragment() {

    private var username: String? = null


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        arguments?.let {
            username = it.getString("username")
        }
    }


    private fun createData(): List<Fliptop> {
        //Get data from the repository
        val names = FakeRepository.presidentName
        val orders = FakeRepository.presidentOrder
        val portraits = FakeRepository.portrait

        val fliptopData = ArrayList<Fliptop>()
        fliptopid.values().forEach { fliptopID ->
            //If the Id is in all lists, add president to the ArrayList
            if (containsId(fliptopID, names, orders, portraits)) {
                fliptopData.add(
                    Fliptop(
                        name = names[fliptopID]!!,
                        caption = orders[fliptopID]!!,
                        image = portraits[fliptopID]!!
                    )
                )
            }
        }

        return fliptopData
    }


    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.fragment_homefragment, container, false)

        // Now find the RecyclerView in the inflated layout
        val recyclerView: RecyclerView = view.findViewById(R.id.theBestRecyclerViewOnThePlanet)
        recyclerView.adapter = MyAdapter(createData())
        recyclerView.layoutManager = LinearLayoutManager(requireContext())

        // Set the username in both TextViews
        view.findViewById<TextView>(R.id.username3).text = username

        return view
    }


    private fun containsId(fliptopID: fliptopid, vararg maps: Map<fliptopid, Any>): Boolean {
        maps.forEach {
            if (fliptopID !in it.keys) { return false }
        }
        return true
    }
    companion object {
        fun newInstance(username: String): homefragment {
            val fragment = homefragment()
            val args = Bundle()
            args.putString("username", username)
            fragment.arguments = args
            return fragment
        }
    }


}
