package com.example.exe2

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.credentials.ClearCredentialStateRequest
import androidx.credentials.Credential
import androidx.credentials.CredentialManager
import androidx.credentials.CustomCredential
import androidx.credentials.GetCredentialRequest
import androidx.credentials.exceptions.ClearCredentialException
import androidx.credentials.exceptions.GetCredentialException
import androidx.lifecycle.lifecycleScope
import com.google.android.libraries.identity.googleid.GetGoogleIdOption
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential.Companion.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.auth.GoogleAuthProvider
import com.google.firebase.auth.auth
import com.google.firebase.Firebase
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    // Hardcoded login credentials
    private val validUsername = "admin"
    private val validPassword = "a"

    // [START declare_auth]
    private lateinit var auth: FirebaseAuth
    // [END declare_auth]

    // [START declare_credential_manager]
    private lateinit var credentialManager: CredentialManager
    // [END declare_credential_manager]

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val usernameEditText = findViewById<EditText>(R.id.usernameid)
        val passwordEditText = findViewById<EditText>(R.id.editTextTextPassword)
        val loginButton = findViewById<Button>(R.id.buttonloginid)
        // CHANGE HERE: Use facebook_login for the Google Sign-In button
        val googleSignInButton = findViewById<Button>(R.id.signinbutton)

        // [START initialize_auth]
        // Initialize Firebase Auth
        auth = Firebase.auth
        // [END initialize_auth]

        // [START initialize_credential_manager]
        // Initialize Credential Manager
        credentialManager = CredentialManager.create(baseContext)
        // [END initialize_credential_manager]

        loginButton.setOnClickListener {
            val inputUsername = usernameEditText.text.toString().trim()
            val inputPassword = passwordEditText.text.toString().trim()

            if (inputUsername == validUsername && inputPassword == validPassword) {
                // Login success, pass the username to the Homepage
                val intentToHomepage = Intent(this, mainmenu::class.java)
                intentToHomepage.putExtra("USER_NAME", inputUsername)
                startActivity(intentToHomepage)
                finish()
            } else {
                // Login failed
                Toast.makeText(this, "The password is wrong, please try again", Toast.LENGTH_SHORT).show()
            }
        }

        // Set the click listener for the Google Sign-In button
        googleSignInButton.setOnClickListener {
            launchCredentialManager()
        }
    }

    // [START on_start_check_user]
    override fun onStart() {
        super.onStart()
        // Check if user is signed in (non-null) and update UI accordingly.
        val currentUser = auth.currentUser
        updateUI(currentUser)
    }
    // [END on_start_check_user]


    private fun launchCredentialManager() {
        // [START create_credential_manager_request]
        // Instantiate a Google sign-in request
        val googleIdOption = GetGoogleIdOption.Builder()
            // Your server's client ID, not your Android client ID.
            .setServerClientId(getString(R.string.default_web_client_id))
            // Allow all Google accounts on the device to be shown, not just pre-authorized ones.
            .setFilterByAuthorizedAccounts(false) // <--- CHANGE THIS LINE TO 'false'
            .build()

        // Create the Credential Manager request
        val request = GetCredentialRequest.Builder()
            .addCredentialOption(googleIdOption)
            .build()
        // [END create_credential_manager_request]

        lifecycleScope.launch {
            try {
                // Launch Credential Manager UI
                val result = credentialManager.getCredential(
                    context = baseContext,
                    request = request
                )

                // Extract credential from the result returned by Credential Manager
                handleSignIn(result.credential)
            } catch (e: GetCredentialException) {
                Log.e(TAG, "Couldn't retrieve user's credentials: ${e.localizedMessage}")
                Toast.makeText(baseContext, "Google Sign-In failed: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
            }
        }
    }

    // [START handle_sign_in]
    private fun handleSignIn(credential: Credential) {
        // Check if credential is of type Google ID
        if (credential is CustomCredential && credential.type == TYPE_GOOGLE_ID_TOKEN_CREDENTIAL) {
            // Create Google ID Token
            val googleIdTokenCredential = GoogleIdTokenCredential.createFrom(credential.data)

            // Sign in to Firebase with using the token
            firebaseAuthWithGoogle(googleIdTokenCredential.idToken)
        } else {
            Log.w(TAG, "Credential is not of type Google ID!")
            Toast.makeText(baseContext, "Google Sign-In failed: Invalid credential type.", Toast.LENGTH_SHORT).show()
        }
    }
    // [END handle_sign_in]

    // [START auth_with_google]
    private fun firebaseAuthWithGoogle(idToken: String) {
        val credential = GoogleAuthProvider.getCredential(idToken, null)
        auth.signInWithCredential(credential)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    // Sign in success, update UI with the signed-in user's information
                    Log.d(TAG, "signInWithCredential:success")
                    val user = auth.currentUser
                    updateUI(user)
                } else {
                    // If sign in fails, display a message to the user
                    Log.w(TAG, "signInWithCredential:failure", task.exception)
                    Toast.makeText(baseContext, "Authentication failed: ${task.exception?.localizedMessage}", Toast.LENGTH_LONG).show()
                    updateUI(null)
                }
            }
    }
    // [END auth_with_google]

    // [START sign_out]
    private fun signOut() {
        // Firebase sign out
        auth.signOut()

        // When a user signs out, clear the current user credential state from all credential providers.
        lifecycleScope.launch {
            try {
                val clearRequest = ClearCredentialStateRequest()
                credentialManager.clearCredentialState(clearRequest)
                updateUI(null)
                Toast.makeText(baseContext, "Signed out successfully.", Toast.LENGTH_SHORT).show()
            } catch (e: ClearCredentialException) {
                Log.e(TAG, "Couldn't clear user credentials: ${e.localizedMessage}")
                Toast.makeText(baseContext, "Error signing out: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
            }
        }
    }
    // [END sign_out]

    private fun updateUI(user: FirebaseUser?) {
        if (user != null) {
            // User is signed in (either hardcoded or Google)
            // You can navigate to Homepage here for Google sign-in   mainmenu
            val intentToHomepage = Intent(this,mainmenu::class.java)
            intentToHomepage.putExtra("USER_NAME", user.displayName ?: user.email ?: "Google User")
            startActivity(intentToHomepage)
            finish()
        } else {
            // User is signed out or not logged in
            Log.d(TAG, "User is signed out or null.")
        }
    }

    companion object {
        private const val TAG = "MainActivity"
    }
}


