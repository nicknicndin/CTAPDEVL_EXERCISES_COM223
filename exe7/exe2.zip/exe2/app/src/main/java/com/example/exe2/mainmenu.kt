package com.example.exe2

import android.annotation.SuppressLint
import android.os.Bundle
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.fragment.app.Fragment
import com.google.android.material.bottomnavigation.BottomNavigationView

class mainmenu : AppCompatActivity() {
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_mainmenu)

        val username = intent.getStringExtra("EXTRA_MESSAGE")


        val profilefragment = profilefragment()
        val notificationfragment = notificationfragment()
        val searchfragment = searchfragment()
        val homefragment = homefragment.newInstance(username ?: "")

        setFragment(homefragment)


        val bottomNavigationView: BottomNavigationView = findViewById(R.id.bottomNavigationView)

        bottomNavigationView.setOnItemSelectedListener { item ->
            when (item.itemId) {

                R.id.home -> setFragment(homefragment)
                R.id.profile -> setFragment(profilefragment)
                R.id.notif -> setFragment(notificationfragment)
                R.id.search -> setFragment(searchfragment)
            }
            true
        }





    }

    private fun setFragment(fragment: Fragment) =
        supportFragmentManager.beginTransaction().apply {
            replace(R.id.flFragment, fragment)
            commit()


        }

}