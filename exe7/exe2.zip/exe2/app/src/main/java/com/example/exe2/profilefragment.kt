package com.example.exe2

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.fragment.app.Fragment
import android.widget.ImageView
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import com.example.exe2.R

class profilefragment : Fragment(R.layout.fragment_profilefragment) {

    private lateinit var pickImageLauncher1: ActivityResultLauncher<Intent>
    private lateinit var pickImageLauncher2: ActivityResultLauncher<Intent>

    private lateinit var profilelogoid: ImageView
    private lateinit var imageprofile1: ImageView

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)

        // Get references to your views
        profilelogoid = view.findViewById(R.id.profilelogoid)
        imageprofile1 = view.findViewById(R.id.imageprofile1)

        // Image picker for profile picture
        pickImageLauncher1 =
            registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
                if (result.resultCode == Activity.RESULT_OK) {
                    val uri = result.data?.data
                    profilelogoid.setImageURI(uri)
                }
            }

        // Image picker for story
        pickImageLauncher2 =
            registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
                if (result.resultCode == Activity.RESULT_OK) {
                    val uri = result.data?.data
                    imageprofile1.setImageURI(uri)
                }
            }

        // Launch image picker when profile is clicked
        profilelogoid.setOnClickListener {
            val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                type = "image/*"
            }
            pickImageLauncher1.launch(intent)
        }

        // Launch image picker when "add story" is clicked
        imageprofile1.setOnClickListener {
            val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                type = "image/*"
            }
            pickImageLauncher2.launch(intent)
        }
    }
}
