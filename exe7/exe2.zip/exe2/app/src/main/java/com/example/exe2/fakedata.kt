package com.example.exe2

object FakeRepository {
    val presidentName = mapOf(
        fliptopid.LOONIE to "LOONIE",
        fliptopid.MHOT to "MHOT",
        fliptopid.SAKMAESTRO to "CHOKEMAESTRO",
        fliptopid.GL to "GL",
        fliptopid.APEKZ to "APEKZ",
        fliptopid.CRIPLI to "CRIPLI",
        fliptopid.FROOZ to "FROOZ",
        fliptopid.BLKD to "BLKD",
        fliptopid.SMUGGLAZ to "SMUGGLAZ",
        fliptopid.ZAITO to "ZAITO",
    )

    val presidentOrder = mapOf(
        fliptopid.LOONIE to "HANGGANG FLIPTOP KA LANG, PANG COLISEUM NA TOH",
        fliptopid.MHOT to "ISANG TAON KA NG PATAY",
        fliptopid.SAKMAESTRO to "YUNG LAST TWO LINES HAHAYAAN KONG CROWD ANG MAG SPIT",
        fliptopid.GL to "WALANG PANAMA YAN GOAT KASI AKO AY TIMELESS",
        fliptopid.APEKZ to "TOTOO NAMAN YUNG MGA BANAT NI AKATA",
        fliptopid.CRIPLI to "PAG SINAPAKG KITA TATLONG ARAW KANG TULOG PAG GISING MO PUYAT KAPA",
        fliptopid.FROOZ to "AKALA KO BA LINGUSTIC MAJOR KA",
        fliptopid.BLKD to "WALANG MALI SA PAGLABAN, MAY MALI KAYALUMABAN",
        fliptopid.SMUGGLAZ to "GINAGAMIT KA NGA BA NG DIYOS, O IKAW YUNG GUMAGAMIT SA KANYA?",
        fliptopid.ZAITO to "TAE"
    )

    val portrait = mapOf(
        fliptopid.LOONIE to R.drawable.loonie,
        fliptopid.MHOT to R.drawable.mhot   ,
        fliptopid.SAKMAESTRO to R.drawable.sakmaestro,
        fliptopid.GL to R.drawable.gl,
        fliptopid.APEKZ to R.drawable.apekz,
        fliptopid.CRIPLI to R.drawable.cripli,
        fliptopid.FROOZ to R.drawable.frooz,
        fliptopid.BLKD to R.drawable.blkd,
        fliptopid.SMUGGLAZ to R.drawable.smugglaz,
        fliptopid.ZAITO to R.drawable.zaito
    )
}