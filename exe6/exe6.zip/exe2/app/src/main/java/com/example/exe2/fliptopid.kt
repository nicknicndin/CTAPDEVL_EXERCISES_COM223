package com.example.exe2

enum class fliptopid {
    LOONIE, MHOT, SAKMAESTRO, GL, APEKZ, CRIPLI, FROOZ, BLKD, SMUGGLAZ, ZAITO
}