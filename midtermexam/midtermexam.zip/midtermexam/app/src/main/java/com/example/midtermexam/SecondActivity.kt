package com.example.midtermexam

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class SecondActivity : AppCompatActivity() {
    private val TAG = "LOG DETECTED"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.secondactivity)



        val secondbutton = findViewById<Button>(R.id.secondbutton)
        val getinputID = intent.getStringExtra("EXTRA_MESSAGE")


        findViewById<TextView>(R.id.getInput).text = getinputID

        secondbutton.setOnClickListener {
            android.util.Log.d("DEBUG", "button clicked")
            passdata()
        }

    }

    private fun passdata() {
        val getInput = findViewById<TextView>(R.id.getInput)
        val getinputID = getInput.text.toString()
        val i = Intent(this, ThirdActivity::class.java)
        i.putExtra("EXTRA_MESSAGE", getinputID)
        startActivity(i)

    }
    override fun onStart() {
        super.onStart()
        Log.d(TAG, "Activity has started ")
    }

    override fun onResume() {
        super.onResume()
        Log.d(TAG, "Activity has resumed")
    }

    override fun onPause() {
        super.onPause()
        Log.d(TAG, "Activity has paused ")
    }

    override fun onStop() {
        super.onStop()
        Log.d(TAG, "Activity has stopped")
    }


    override fun onDestroy() {
        super.onDestroy()
        Log.d(TAG, "Activity has destroyed")
    }


}
