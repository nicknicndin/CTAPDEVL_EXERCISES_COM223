package com.example.midtermexam

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class FirstActivity : AppCompatActivity() {
    private val TAG = "LOG DETECTED"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.firstactivity)




        val inputID = findViewById<EditText>(R.id.inputID)
        val firstbutton = findViewById<Button>(R.id.firstbutton)

        firstbutton.setOnClickListener {
            android.util.Log.d("DEBUG", "button clicked")
            passdata()
        }




    }

    private fun passdata() {
        val inputID = findViewById<EditText>(R.id.inputID)
        val getinputID = inputID.text.toString()
        val i = Intent(this, SecondActivity::class.java)
        i.putExtra("EXTRA_MESSAGE", getinputID)
        startActivity(i)

    }
    override fun onStart() {
        super.onStart()
        Log.d(TAG, "Activity has started ")
    }

    override fun onResume() {
        super.onResume()
        Log.d(TAG, "Activity has resumed")
    }

    override fun onPause() {
        super.onPause()
        Log.d(TAG, "Activity has paused ")
    }

    override fun onStop() {
        super.onStop()
        Log.d(TAG, "Activity has stopped")
    }


    override fun onDestroy() {
        super.onDestroy()
        Log.d(TAG, "Activity has destroyed")
    }




    }

