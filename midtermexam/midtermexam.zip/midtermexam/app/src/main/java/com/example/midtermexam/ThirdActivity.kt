package com.example.midtermexam

import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat

class ThirdActivity : AppCompatActivity() {
    private val TAG = "LOG DETECTED"
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.thirdactivity)


        val getinputID = intent.getStringExtra("EXTRA_MESSAGE")


        findViewById<TextView>(R.id.getinput2).text = getinputID

        val githubbutton = findViewById<Button>(R.id.githubbutton)
        githubbutton.setOnClickListener {
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse("https://github.com/nicknicndin"))
            startActivity(intent)
        }
    }
    override fun onStart() {
        super.onStart()
        Log.d(TAG, "Activity has started ")
    }

    override fun onResume() {
        super.onResume()
        Log.d(TAG, "Activity has resumed")
    }

    override fun onPause() {
        super.onPause()
        Log.d(TAG, "Activity has paused ")
    }

    override fun onStop() {
        super.onStop()
        Log.d(TAG, "Activity has stopped")
    }


    override fun onDestroy() {
        super.onDestroy()
        Log.d(TAG, "Activity has destroyed")
    }

}
