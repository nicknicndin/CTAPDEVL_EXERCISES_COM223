package com.example.exe2

import android.app.Activity
import android.content.Intent
import android.os.Bundle
import android.widget.ImageButton
import android.widget.ImageView
import androidx.activity.result.ActivityResultLauncher
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

class profile : AppCompatActivity() {

    private lateinit var pickImageLauncher1: ActivityResultLauncher<Intent>

    private lateinit var pickImageLauncher2: ActivityResultLauncher<Intent>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.profile)

        val profilelogoid: ImageButton = findViewById(R.id.profilelogoid)
        val postprofile: ImageButton = findViewById(R.id.postprofile)
        val imageprofile1: ImageView = findViewById(R.id.imageprofile1)

        pickImageLauncher1 =
            registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
                if (result.resultCode == Activity.RESULT_OK) {
                    val uri = result.data?.data
                    profilelogoid.setImageURI(uri)
                }
            }

        pickImageLauncher2 =
            registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
                if (result.resultCode == Activity.RESULT_OK) {
                    val uri = result.data?.data
                    imageprofile1.setImageURI(uri)
                }
            }

        profilelogoid.setOnClickListener {
            val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                type = "image/*"
            }
            pickImageLauncher1.launch(intent)

        }

        postprofile.setOnClickListener {
            val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                type = "image/*"
            }
            pickImageLauncher2.launch(intent)
        }

    }

}