package com.example.exe2

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.exe2.R
import com.example.exe2.frontpage

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val usernameid = findViewById<EditText>(R.id.usernameid)
        val buttonloginid = findViewById<Button>(R.id.buttonloginid)


        buttonloginid.setOnClickListener {
            android.util.Log.d("DEBUG", "Login button clicked")
            passdata()
        }

    }
    private fun passdata() {
        val usernameid = findViewById<EditText>(R.id.usernameid)
        val username = usernameid.text.toString()
        val intent = Intent (this, frontpage ::class.java).also {
            it.putExtra("EXTRA_MESSAGE", username)
            startActivity(it)

    }



}



}