package com.example.exe2

import android.os.Bundle
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity

class frontpage : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.front_page)



        val username = intent.getStringExtra("EXTRA_MESSAGE")

        findViewById<TextView>(R.id.username1).text = username
        findViewById<TextView>(R.id.username2).text = username

        }

}











